import React from 'react'

const PostByAuthor = () => {
  return (
    <div>PostByAuthor</div>
  )
}

export default PostByAuthor;