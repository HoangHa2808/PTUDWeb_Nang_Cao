import React from 'react'

const About = () => {
  return (
    <div>
      <h1 className='text-center mb-5'>
        TIPS & TRICKS BLOG
      </h1>

      <p>
        You are responsible for creating the content for this page
      </p>

      <p className="text-center">
        <img className='img-fluid' src="/tips.jpg" alt="TAT BLOG" />
      </p>

      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque, facilis! Similique error autem facilis.
        Iusto nisi reprehenderit consequatur pariatur accusamus atque, autem suscipit! Exercitationem culpa illo enim,
        hic repudiandae soluta ducimus, architecto quod commodi ut voluptatum consequuntur iste, quidem maiores nihil
        praesentium? Rerum voluptatibus eum omnis esse sit inventore numquam.
      </p>

      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque, facilis! Similique error autem facilis.
        Iusto nisi reprehenderit consequatur pariatur accusamus atque, autem suscipit! Exercitationem culpa illo enim,
        hic repudiandae soluta ducimus, architecto quod commodi ut voluptatum consequuntur iste, quidem maiores nihil
        praesentium? Rerum voluptatibus eum omnis esse sit inventore numquam.
      </p>

      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque, facilis! Similique error autem facilis.
        Iusto nisi reprehenderit consequatur pariatur accusamus atque, autem suscipit! Exercitationem culpa illo enim,
        hic repudiandae soluta ducimus, architecto quod commodi ut voluptatum consequuntur iste, quidem maiores nihil
        praesentium? Rerum voluptatibus eum omnis esse sit inventore numquam.
      </p>
    </div>
  )
}

export default About;