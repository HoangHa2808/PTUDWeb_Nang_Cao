import React from 'react'

const PostByCategory = () => {
  return (
    <div>PostByCategory</div>
  )
}

export default PostByCategory;