import React from 'react'

const FeaturedPosts = () => {
  return (
    <div>FeaturedPosts</div>
  )
}

export default FeaturedPosts;