export const authorsData = [
    {
        "id": 1,
        "fullName": "Jason Mouth",
        "urlSlug": "jason-mouth",
        "imageUrl": null,
        "joinedDate": "2022-10-21T00:00:00",
        "email": "json@gmail.com",
        "postCount": 6
    },
    {
        "id": 2,
        "fullName": "Jessica Wonder",
        "urlSlug": "jessica-wonder",
        "imageUrl": null,
        "joinedDate": "2020-04-19T00:00:00",
        "email": "jessica665@motip.com",
        "postCount": 5
    },
    {
        "id": 3,
        "fullName": "Kathy Smith",
        "urlSlug": "kathy-smith",
        "imageUrl": null,
        "joinedDate": "2010-06-09T00:00:00",
        "email": "kathy.smith@iworld.com",
        "postCount": 4
    },
    {
        "id": 4,
        "fullName": "Cryten Boomber",
        "urlSlug": "cryten-boomber",
        "imageUrl": null,
        "joinedDate": "2020-04-19T00:00:00",
        "email": "crysten@gmail.com",
        "postCount": 5
    },
    {
        "id": 5,
        "fullName": "Julian Smart",
        "urlSlug": "julian-smart",
        "imageUrl": null,
        "joinedDate": "2010-06-09T00:00:00",
        "email": "julian.smart@press.us",
        "postCount": 9
    }
];