export const tagsData = [
    {
      "id": 7,
      "name": "Bootstrap",
      "urlSlug": "bootstrap",
      "postCount": 10
    },
    {
      "id": 8,
      "name": "Tailwind CSS",
      "urlSlug": "tailwind-css",
      "postCount": 2
    },
    {
      "id": 2,
      "name": "ASP.NET MVC",
      "urlSlug": "asp-net-mvc",
      "postCount": 7
    },
    {
      "id": 6,
      "name": "Neural Network",
      "urlSlug": "neural-network",
      "postCount": 21
    },
    {
      "id": 1,
      "name": "Google",
      "urlSlug": "google",
      "postCount": 16
    },
    {
      "id": 4,
      "name": "Blazor",
      "urlSlug": "blazor",
      "postCount": 1
    },
    {
      "id": 10,
      "name": "Data Structures",
      "urlSlug": "data-structures",
      "postCount": 5
    }
  ];