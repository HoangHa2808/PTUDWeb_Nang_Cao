<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryController extends Controller
{
    //
    public function index(Request $request)
    {
        return view('category.index');
        
    }

    public function addnew(Request $request){
        return view('category.addnew');
    }
}
