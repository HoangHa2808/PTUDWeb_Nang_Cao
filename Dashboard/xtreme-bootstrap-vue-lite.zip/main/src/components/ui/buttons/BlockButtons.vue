<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Block Buttons -->
  <!-- ----------------------------------------------------------------------------- -->

  <b-card class="w-100 mb-4" no-body>
    <div class="p-35">
      <div class="d-flex align-items-start">
        <div>
          <h4 class="card-title mb-1">Block Buttons</h4>
        </div>
      </div>
    </div>
    <hr class="m-0" />
    <b-card-body>
      <b-button block variant="primary">Block Button</b-button>
    </b-card-body>
  </b-card>
</template>

<script>
export default {
  name: "BlockButtons",

  data: () => ({}),
};
</script>