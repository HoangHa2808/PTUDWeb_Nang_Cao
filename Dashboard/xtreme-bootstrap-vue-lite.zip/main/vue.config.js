module.exports = {
  publicPath: "/demos/free-admin-templates/xtreme-vuesax-free/main/",
};
